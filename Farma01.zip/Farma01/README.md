# Business-Intelligence-pharmaceuticals
BI project that helps decision making regarding the pharmaceuticals products sold. based on a data warehouse on relational database (PostgreSQL) using Pentaho Data Integration for the ETL process, and Pentaho Workbench for building the Mondrian cube.
